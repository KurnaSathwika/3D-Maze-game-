using UnityEngine;
using System.Collections.Generic;

public class MazeGenerator : MonoBehaviour
{
    public int width = 21;
    public int height = 21;
    public GameObject wallPrefab;
    public GameObject exitPrefab;
    public Transform mazeParent;

    float spacing = 2f;
    int[,] maze;

    void Start()
    {
        GenerateMaze();
    }

    void GenerateMaze()
    {
        foreach (Transform child in mazeParent)
            Destroy(child.gameObject);

        maze = new int[width, height];

        for (int x = 0; x < width; x++)
            for (int y = 0; y < height; y++)
                maze[x, y] = 1;

        Carve(1, 1);

        float offX = width * spacing / 2f;
        float offZ = height * spacing / 2f;

        for (int x = 0; x < width; x++)
        {
            for (int z = 0; z < height; z++)
            {
                if (maze[x, z] == 1)
                {
                    Vector3 pos = new Vector3(x * spacing - offX, 1, z * spacing - offZ);
                    Instantiate(wallPrefab, pos, Quaternion.identity, mazeParent);
                }
            }
        }

        // ENTRY OPENING
        maze[1,0] = 0;

        // EXIT OPENING
        Vector3 exitPos = new Vector3((width-2)*spacing - offX, 1, (height-2)*spacing - offZ);
        Instantiate(exitPrefab, exitPos, Quaternion.identity, mazeParent);
    }

    void Carve(int x, int y)
    {
        int[] dirs = {0,1,2,3};
        Shuffle(dirs);
        maze[x,y] = 0;

        foreach(int d in dirs)
        {
            int nx=x, ny=y;
            if(d==0) nx+=2;
            if(d==1) nx-=2;
            if(d==2) ny+=2;
            if(d==3) ny-=2;

            if(nx>0 && ny>0 && nx<width-1 && ny<height-1 && maze[nx,ny]==1)
            {
                maze[(x+nx)/2,(y+ny)/2]=0;
                Carve(nx,ny);
            }
        }
    }

    void Shuffle(int[] a)
    {
        for(int i=0;i<a.Length;i++)
        {
            int r=Random.Range(0,a.Length);
            int t=a[i]; a[i]=a[r]; a[r]=t;
        }
    }
}