using UnityEngine;

public class CameraLookAt : MonoBehaviour
{
    void LateUpdate()
    {
        transform.LookAt(Vector3.zero);
    }
}