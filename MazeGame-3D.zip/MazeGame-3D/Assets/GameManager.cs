using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    public float timeLimit = 40f;
    float timer;
    bool gameEnded = false;

    public Text timerText;
    public GameObject resultPanel;
    public Text resultText;

    void Awake()
    {
        Instance = this;
    }

    void Start()
    {
        Time.timeScale = 1;
        timer = timeLimit;
        resultPanel.SetActive(false);
    }

    void Update()
    {
        if (gameEnded) return;

        timer -= Time.deltaTime;
        timerText.text = "Time: " + Mathf.Ceil(timer).ToString();

        if (timer <= 0)
        {
            ShowResult(false);
        }
    }

    public void WinGame()
    {
        ShowResult(true);
    }

    void ShowResult(bool win)
    {
        gameEnded = true;
        resultPanel.SetActive(true);
        resultText.text = win ? "YOU WIN 🎉" : "YOU LOSE ❌";
        Time.timeScale = 0;
    }

    public void RestartGame()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}