import pandas as pd
import re

def sql_to_pandas(sql_query, df_name="df"):
    # Convert to lowercase for easier parsing
    query = sql_query.lower()

    # Extract SELECT columns
    select_match = re.search(r"select (.*?) from", query)
    columns = select_match.group(1).split(",")
    columns = [col.strip() for col in columns]

    # Extract WHERE condition
    where_match = re.search(r"where (.*)", query)
    condition = where_match.group(1) if where_match else None

    # Build pandas query
    pandas_code = df_name

    if condition:
        pandas_code += f"[{df_name}['{condition.split()[0]}'] {condition.split()[1]} {condition.split()[2]}]"

    pandas_code += f"[{columns}]"

    return pandas_code


# 🔹 Sample SQL Query
sql = "SELECT name, salary FROM employees WHERE salary > 50000"

# 🔹 Generate Pandas Code
translated_code = sql_to_pandas(sql)

print("Generated Pandas Code:")
print(translated_code)


# 🔹 Test on Sample DataFrame
data = {
    "name": ["Arsha", "Rahul", "Priya", "Kiran"],
    "salary": [40000, 60000, 75000, 45000]
}

df = pd.DataFrame(data)

# Execute generated code
result = eval(translated_code)

print("\nResult:")
print(result)