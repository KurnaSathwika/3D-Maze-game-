using UnityEngine;

public class BoundaryWalls : MonoBehaviour
{
    public float groundSize = 40f;   // same as your ground scale
    public float wallHeight = 3f;
    public float thickness = 1f;

    void Start()
    {
        CreateWall("Wall_Left",
            new Vector3(-groundSize / 2, wallHeight / 2, 0),
            new Vector3(thickness, wallHeight, groundSize));

        CreateWall("Wall_Right",
            new Vector3(groundSize / 2, wallHeight / 2, 0),
            new Vector3(thickness, wallHeight, groundSize));

        CreateWall("Wall_Top",
            new Vector3(0, wallHeight / 2, groundSize / 2),
            new Vector3(groundSize, wallHeight, thickness));

        CreateWall("Wall_Bottom",
            new Vector3(0, wallHeight / 2, -groundSize / 2),
            new Vector3(groundSize, wallHeight, thickness));
    }

    void CreateWall(string name, Vector3 pos, Vector3 scale)
    {
        GameObject wall = GameObject.CreatePrimitive(PrimitiveType.Cube);
        wall.name = name;
        wall.transform.position = pos;
        wall.transform.localScale = scale;

        // make invisible
        wall.GetComponent<MeshRenderer>().enabled = false;
    }
}