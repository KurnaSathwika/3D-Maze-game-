class RestaurantReservationSystem:
    def __init__(self):
        self.customers = {}
        self.tables = {}
        self.reservations = []
        self.reservation_id_counter = 1

    # Add customer
    def add_customer(self, customer_id, name):
        self.customers[customer_id] = name

    # Add table
    def add_table(self, table_id, capacity):
        self.tables[table_id] = capacity

    # Make reservation
    def make_reservation(self, customer_id, table_id, date, time, guests):
        # Check if table is already booked
        for r in self.reservations:
            if r['table_id'] == table_id and r['date'] == date and r['time'] == time:
                print(f" Table {table_id} already booked at {time}")
                return

        reservation = {
            'reservation_id': self.reservation_id_counter,
            'customer_id': customer_id,
            'customer_name': self.customers[customer_id],
            'table_id': table_id,
            'capacity': self.tables[table_id],
            'date': date,
            'time': time,
            'guests': guests,
            'status': 'confirmed'
        }

        self.reservations.append(reservation)
        self.reservation_id_counter += 1

    # Check availability
    def check_table_availability(self, date, time):
        booked_tables = [
            r['table_id']
            for r in self.reservations
            if r['date'] == date and r['time'] == time
        ]

        available = [
            (tid, cap)
            for tid, cap in self.tables.items()
            if tid not in booked_tables
        ]

        return available

    # List reservations for a date
    def list_reservations_for_date(self, date):
        result = []
        for r in self.reservations:
            if r['date'] == date:
                result.append((
                    r['reservation_id'],
                    r['customer_name'],
                    r['capacity'],
                    r['time'],
                    r['guests'],
                    r['status']
                ))
        return result

    # Most popular reservation time
    def most_popular_reservation_time(self):
        time_count = {}

        for r in self.reservations:
            t = r['time']
            time_count[t] = time_count.get(t, 0) + 1

        most_popular = max(time_count.items(), key=lambda x: x[1])
        return most_popular


# ---------------- MAIN PROGRAM ---------------- #

system = RestaurantReservationSystem()

# Add customers
system.add_customer(1, "John Doe")
system.add_customer(2, "Jane Smith")

# Add tables
system.add_table(1, 2)
system.add_table(2, 4)
system.add_table(3, 6)

# Make reservations
system.make_reservation(1, 2, '2026-04-10', '19:00', 4)
system.make_reservation(2, 3, '2026-04-10', '20:00', 5)
system.make_reservation(1, 2, '2026-04-10', '19:00', 2)  # duplicate (blocked)

# Check availability
available = system.check_table_availability('2026-04-10', '19:00')
print("\nAvailable tables at 19:00 on 2026-04-10:")
for table_id, capacity in available:
    print(f"Table ID: {table_id}, Capacity: {capacity}")

# List reservations
reservations = system.list_reservations_for_date('2026-04-10')
print("\nReservations on 2026-04-10:")
for r in reservations:
    print(f"ID: {r[0]}, Name: {r[1]}, Capacity: {r[2]}, Time: {r[3]}, Guests: {r[4]}, Status: {r[5]}")

# Most popular time
popular_time = system.most_popular_reservation_time()
print("\nMost popular reservation time:", popular_time)